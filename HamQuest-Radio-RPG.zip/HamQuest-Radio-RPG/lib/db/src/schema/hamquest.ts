import { createInsertSchema } from "drizzle-zod";
import { integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const hamquestPlayersTable = pgTable("hamquest_players", {
  id: serial("id").primaryKey(),
  username: text("username").notNull(),
  callsign: text("callsign").notNull(),
  level: integer("level").notNull().default(1),
  xp: integer("xp").notNull().default(0),
  streak: integer("streak").notNull().default(0),
  contacts: integer("contacts").notNull().default(0),
  regions: integer("regions").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertHamquestPlayerSchema = createInsertSchema(hamquestPlayersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertHamquestPlayer = z.infer<typeof insertHamquestPlayerSchema>;
export type HamquestPlayer = typeof hamquestPlayersTable.$inferSelect;