import { eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  AnswerHamquestSignalBody,
  CompleteHamquestMissionParams,
  ListHamquestQuestionsQueryParams,
  RespondHamquestQsoBody,
} from "@workspace/api-zod";
import { db, hamquestPlayersTable, type HamquestPlayer } from "@workspace/db";

const router: IRouter = Router();

const missionSeed = [
  {
    id: "first-contact",
    title: "First Contact",
    description: "Complete your first simulated QSO with good radio etiquette.",
    category: "FIELD OPS",
    reward: 180,
    progress: 0,
    total: 1,
    status: "active",
    requiredLevel: 1,
  },
  {
    id: "signal-scout",
    title: "Signal Scout",
    description: "Identify five different signals in the training lab.",
    category: "SIGNAL LAB",
    reward: 120,
    progress: 3,
    total: 5,
    status: "in-progress",
    requiredLevel: 1,
  },
  {
    id: "twenty-meter-dx",
    title: "Twenty Meter DX",
    description: "Reach Europe on the 20m band from the exploration map.",
    category: "EXPLORATION",
    reward: 300,
    progress: 0,
    total: 1,
    status: "locked",
    requiredLevel: 5,
  },
];

const missionTracks = [
  {
    category: "FIELD OPS",
    nouns: ["Backyard Net", "Mountain Relay", "Coastal Watch", "Night Net", "Emergency Drill"],
    actions: ["Check in to", "Log a clean exchange on", "Run a directed net on", "Relay traffic through", "Complete a timed contact on"],
    detail: "Practice clear operating procedure while keeping the exchange concise.",
  },
  {
    category: "BANDCRAFT",
    nouns: ["80m", "40m", "20m", "15m", "10m"],
    actions: ["Tune", "Compare", "Map", "Scout", "Work"],
    detail: "Build band awareness and learn when each slice of spectrum comes alive.",
  },
  {
    category: "PROPAGATION",
    nouns: ["Greyline", "Sporadic-E", "Solar Flare", "Aurora", "F2 Layer"],
    actions: ["Trace", "Predict", "Confirm", "Chase", "Document"],
    detail: "Read the ionosphere and turn a forecast into a real operating decision.",
  },
  {
    category: "RADIO ETIQUETTE",
    nouns: ["Callsigns", "Signal Reports", "Q-Signals", "Phonetics", "Band Plans"],
    actions: ["Master", "Practice", "Decode", "Polish", "Review"],
    detail: "Use the language of the bands with confidence and respect for other operators.",
  },
  {
    category: "FIELD ENGINEERING",
    nouns: ["Dipole", "Counterpoise", "SWR", "Ground Plane", "Feedline"],
    actions: ["Build", "Measure", "Diagnose", "Optimize", "Deploy"],
    detail: "Turn a practical station problem into a repeatable field solution.",
  },
  {
    category: "DIGITAL MODES",
    nouns: ["FT8", "JS8Call", "APRS", "Winlink", "Packet"],
    actions: ["Configure", "Decode", "Route", "Validate", "Operate"],
    detail: "Work a digital mode and explain why its signal behaves the way it does.",
  },
];

const generatedMissions = Array.from({ length: 120 }, (_, index) => {
  const track = missionTracks[index % missionTracks.length];
  const noun = track.nouns[Math.floor(index / missionTracks.length) % track.nouns.length];
  const action = track.actions[Math.floor(index / (missionTracks.length * track.nouns.length)) % track.actions.length];
  const requiredLevel = 2 + Math.floor(index / 10);
  const total = 1 + (index % 4);
  return {
    id: `expedition-${String(index + 1).padStart(3, "0")}`,
    title: `${action} ${noun}`,
    description: `${track.detail} Expedition ${index + 1} adds a new constraint so the skill sticks.`,
    category: track.category,
    reward: 90 + requiredLevel * 18 + (index % 3) * 20,
    progress: 0,
    total,
    status: "locked",
    requiredLevel,
  };
});

const missionCatalog = [...missionSeed, ...generatedMissions];
const completedMissionIds = new Set<string>();

function getMissionsForLevel(level: number) {
  return missionCatalog.map((mission) => {
    const completed = completedMissionIds.has(mission.id);
    return {
      ...mission,
      status: completed ? "complete" : level < mission.requiredLevel ? "locked" : mission.status === "in-progress" ? "in-progress" : "active",
      progress: completed ? mission.total : mission.progress,
    };
  });
}

const activity = [
  {
    id: "activity-1",
    title: "Signal Scout advanced",
    detail: "Correctly identified an FT8 digital burst",
    time: "12 min ago",
    kind: "signal",
  },
  {
    id: "activity-2",
    title: "New region unlocked",
    detail: "Pacific Northwest is now on your map",
    time: "Yesterday",
    kind: "map",
  },
  {
    id: "activity-3",
    title: "Daily streak extended",
    detail: "You are on a 4-day learning streak",
    time: "Yesterday",
    kind: "streak",
  },
];

const signalChallenge = {
  id: "signal-204",
  frequency: "14.074 MHz",
  mode: "FT8 / DIGITAL",
  difficulty: "BEGINNER",
  prompt: "This signal has a narrow, repeating digital cadence. What are you hearing?",
  options: ["CW / Morse", "SSB voice", "FT8 / digital", "Noise / interference"],
  streak: 3,
};

const qsoScenario = {
  id: "qso-001",
  band: "20M",
  callsign: "K7NXR",
  signal: "59",
  location: "Portland, Oregon",
  transcript: [
    { speaker: "K7NXR", text: "CQ CQ, this is K7NXR calling. You are five-nine into Portland." },
  ],
  options: [
    "K7NXR, this is KN6EON. Thanks for the five-nine, you are also five-nine. Over.",
    "Hey! What's up? I can hear you really well.",
    "K7NXR, repeat your callsign and location please.",
  ],
};

const leaderboard = [
  { rank: 1, username: "MorsePilot", callsign: "W1MP", xp: 4820, change: 2, avatar: "MP" },
  { rank: 2, username: "AntennaAtlas", callsign: "N7AT", xp: 4310, change: 0, avatar: "AA" },
  { rank: 3, username: "SignalSmith", callsign: "K4SIG", xp: 3975, change: 1, avatar: "SS" },
  { rank: 4, username: "You", callsign: "KN6EON", xp: 2460, change: 3, avatar: "YO" },
  { rank: 5, username: "RadioNova", callsign: "VE3RN", xp: 2210, change: -1, avatar: "RN" },
];

const propagationSnapshot = {
  updatedAt: "2026-09-15T23:42:00Z",
  dataAsOf: "2026-09-15T23:42:00Z",
  source: "NOAA SWPC",
  sourceUrl: "https://www.swpc.noaa.gov/products/solar-cycle-progression",
  stale: true,
  staleReason: "Waiting for the first live NOAA SWPC refresh.",
  solarFlux: 168,
  sunspots: 142,
  kIndex: 2,
  aIndex: 9,
  headline: "20m and 15m are carrying strong daylight paths across the Pacific.",
  bands: [
    { band: "80m", status: "FAIR", score: 54, bestWindow: "19:00–03:00 UTC", detail: "Reliable regional coverage after sunset." },
    { band: "40m", status: "GOOD", score: 78, bestWindow: "18:00–08:00 UTC", detail: "The most consistent all-around band right now." },
    { band: "20m", status: "EXCELLENT", score: 94, bestWindow: "14:00–23:00 UTC", detail: "Strongest long-haul band in the current forecast." },
    { band: "15m", status: "GOOD", score: 82, bestWindow: "15:00–21:00 UTC", detail: "Open to Europe and the Pacific during daylight." },
    { band: "10m", status: "WATCH", score: 61, bestWindow: "16:00–19:00 UTC", detail: "Short openings are possible around local noon." },
  ],
  paths: [
    { from: "KN6EON", to: "JA", band: "20m", status: "OPEN", distance: "8,900 km", signal: "S9" },
    { from: "KN6EON", to: "VK", band: "15m", status: "FADING", distance: "12,500 km", signal: "S6" },
    { from: "KN6EON", to: "EU", band: "20m", status: "OPEN", distance: "8,700 km", signal: "S8" },
    { from: "KN6EON", to: "SA", band: "40m", status: "SCATTER", distance: "7,900 km", signal: "S5" },
  ],
};

const NOAA_PROPAGATION_SOURCES = {
  flux: "https://services.swpc.noaa.gov/products/summary/10cm-flux.json",
  geomagnetic: "https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json",
  solarCycle: "https://services.swpc.noaa.gov/json/solar-cycle/observed-solar-cycle-indices.json",
} as const;

type PropagationSnapshot = typeof propagationSnapshot;
type NoaaFluxRow = { flux?: number; time_tag?: string };
type NoaaGeomagneticRow = { Kp?: number; a_running?: number; time_tag?: string };
type NoaaSolarCycleRow = { ssn?: number; observed_swpc_ssn?: number; "time-tag"?: string };

let propagationCache: { snapshot: PropagationSnapshot; fetchedAt: number } | null = null;
const PROPAGATION_CACHE_TTL_MS = 5 * 60 * 1000;
const PROPAGATION_STALE_AFTER_MS = 6 * 60 * 60 * 1000;

async function fetchNoaaJson<T>(url: string): Promise<T> {
  const response = await fetch(url, {
    headers: { accept: "application/json" },
    signal: AbortSignal.timeout(5000),
  });
  if (!response.ok) throw new Error(`NOAA SWPC returned ${response.status} for ${url}`);
  return (await response.json()) as T;
}

function propagationStatus(score: number): string {
  if (score >= 84) return "EXCELLENT";
  if (score >= 67) return "GOOD";
  if (score >= 50) return "FAIR";
  return "WATCH";
}

function propagationPathStatus(score: number): string {
  if (score >= 78) return "OPEN";
  if (score >= 58) return "DETECTED";
  if (score >= 42) return "FADING";
  return "SCATTER";
}

function buildLivePropagationSnapshot(solarFlux: number, sunspots: number, kIndex: number, aIndex: number, dataAsOf: string): PropagationSnapshot {
  const solarActivity = Math.max(0, Math.min(1, (solarFlux - 65) / 135));
  const geomagneticPenalty = Math.min(35, kIndex * 5 + aIndex * 0.45);
  const bandDefinitions = [
    { band: "80m", base: 70, solarWeight: 8, geomagneticWeight: 0.25, bestWindow: "19:00–03:00 UTC", detail: "Reliable regional coverage after sunset." },
    { band: "40m", base: 74, solarWeight: 10, geomagneticWeight: 0.35, bestWindow: "18:00–08:00 UTC", detail: "The most consistent all-around band right now." },
    { band: "20m", base: 56, solarWeight: 38, geomagneticWeight: 0.45, bestWindow: "14:00–23:00 UTC", detail: "Strongest long-haul band in the current forecast." },
    { band: "15m", base: 43, solarWeight: 50, geomagneticWeight: 0.5, bestWindow: "15:00–21:00 UTC", detail: "Open to Europe and the Pacific during daylight." },
    { band: "10m", base: 32, solarWeight: 62, geomagneticWeight: 0.6, bestWindow: "16:00–19:00 UTC", detail: "Short openings are possible around local noon." },
  ];
  const bands = bandDefinitions.map((definition) => {
    const score = Math.max(0, Math.min(100, Math.round(definition.base + solarActivity * definition.solarWeight - geomagneticPenalty * definition.geomagneticWeight)));
    return { band: definition.band, status: propagationStatus(score), score, bestWindow: definition.bestWindow, detail: definition.detail };
  });
  const scoreFor = (band: string) => bands.find((item) => item.band === band)?.score ?? 0;
  const pathDefinitions = [
    { to: "JA", band: scoreFor("20m") >= scoreFor("15m") ? "20m" : "15m", distance: "8,900 km" },
    { to: "VK", band: scoreFor("15m") >= scoreFor("20m") ? "15m" : "20m", distance: "12,500 km" },
    { to: "EU", band: scoreFor("20m") >= scoreFor("40m") ? "20m" : "40m", distance: "8,700 km" },
    { to: "SA", band: scoreFor("40m") >= scoreFor("20m") ? "40m" : "20m", distance: "7,900 km" },
  ];
  const paths = pathDefinitions.map((path) => {
    const score = scoreFor(path.band);
    return {
      from: "KN6EON",
      to: path.to,
      band: path.band,
      status: propagationPathStatus(score),
      distance: path.distance,
      signal: `S${Math.max(3, Math.min(9, Math.round(score / 12)))}`,
    };
  });
  const strongestBand = bands.reduce((best, band) => band.score > best.score ? band : best, bands[0]);
  const headline = `${strongestBand.band} is ${strongestBand.status.toLowerCase()} with current solar flux ${solarFlux}; geomagnetic activity is K${kIndex}.`;
  const sourceTimes = [dataAsOf, new Date().toISOString()];
  const freshestSourceTime = sourceTimes.sort().at(-1) ?? dataAsOf;
  const stale = Date.now() - new Date(dataAsOf).getTime() > PROPAGATION_STALE_AFTER_MS;
  return {
    updatedAt: freshestSourceTime,
    dataAsOf,
    source: "NOAA SWPC",
    sourceUrl: "https://www.swpc.noaa.gov/products/space-weather-data",
    stale,
    staleReason: stale ? "NOAA SWPC data is older than the six-hour freshness window." : null,
    solarFlux,
    sunspots,
    kIndex,
    aIndex,
    headline,
    bands,
    paths,
  };
}

async function getPropagationSnapshot(): Promise<PropagationSnapshot> {
  if (propagationCache && Date.now() - propagationCache.fetchedAt < PROPAGATION_CACHE_TTL_MS) {
    return propagationCache.snapshot;
  }

  try {
    const [fluxRows, geomagneticRows, solarCycleRows] = await Promise.all([
      fetchNoaaJson<NoaaFluxRow[]>(NOAA_PROPAGATION_SOURCES.flux),
      fetchNoaaJson<NoaaGeomagneticRow[]>(NOAA_PROPAGATION_SOURCES.geomagnetic),
      fetchNoaaJson<NoaaSolarCycleRow[]>(NOAA_PROPAGATION_SOURCES.solarCycle),
    ]);
    const latestFlux = [...fluxRows].reverse().find((row) => Number.isFinite(row.flux) && row.time_tag);
    const latestGeomagnetic = [...geomagneticRows].reverse().find((row) => Number.isFinite(row.Kp) && Number.isFinite(row.a_running) && row.time_tag);
    const latestSolarCycle = [...solarCycleRows].reverse().find((row) => Number.isFinite(row.ssn) && row["time-tag"]);
    if (!latestFlux || !latestGeomagnetic || !latestSolarCycle) throw new Error("NOAA SWPC returned an incomplete propagation payload.");

    const dataAsOf = [latestFlux.time_tag!, latestGeomagnetic.time_tag!].sort().at(-1) ?? latestFlux.time_tag!;
    const snapshot = buildLivePropagationSnapshot(
      Math.round(latestFlux.flux!),
      Math.round(latestSolarCycle.ssn!),
      Math.round(latestGeomagnetic.Kp!),
      Math.round(latestGeomagnetic.a_running!),
      dataAsOf,
    );
    propagationCache = { snapshot, fetchedAt: Date.now() };
    return snapshot;
  } catch (error) {
    const fallback = {
      ...propagationSnapshot,
      updatedAt: new Date().toISOString(),
      stale: true,
      staleReason: error instanceof Error ? `Live NOAA SWPC refresh failed: ${error.message}` : "Live NOAA SWPC refresh failed.",
    };
    propagationCache = { snapshot: fallback, fetchedAt: Date.now() };
    return fallback;
  }
}

const practiceQuestions = [
  {
    id: "T1A01",
    pool: "technician",
    section: "T1A",
    question: "Which of the following is part of the Basis and Purpose of the Amateur Radio Service?",
    answers: ["Providing personal radio communications for as many citizens as possible", "Providing communications for international contesting", "Advancing skills in the technical and communication phases of the radio art", "All these choices are correct"],
    correctIndex: 2,
    reference: "2026–2030 Technician pool · [97.1]",
  },
  {
    id: "T1A02",
    pool: "technician",
    section: "T1A",
    question: "Which agency regulates and enforces the rules for the Amateur Radio Service in the United States?",
    answers: ["ARRL", "Homeland Security", "The FCC", "All these choices are correct"],
    correctIndex: 2,
    reference: "2026–2030 Technician pool · [97.1]",
  },
  {
    id: "T1A03",
    pool: "technician",
    section: "T1A",
    question: "What do the FCC rules state regarding the use of a phonetic alphabet for station identification in the Amateur Radio Service?",
    answers: ["It is required when transmitting emergency messages", "It is encouraged when using phone emissions", "It is required when in contact with foreign stations", "All these choices are correct"],
    correctIndex: 1,
    reference: "2026–2030 Technician pool · [97.119(b)(2)]",
  },
  {
    id: "G1A01",
    pool: "general",
    section: "G1A",
    question: "On which HF and/or MF amateur bands are there portions where General class licensees cannot transmit?",
    answers: ["60 meters, 30 meters, 17 meters, and 12 meters", "160 meters, 60 meters, 15 meters, and 12 meters", "80 meters, 40 meters, 20 meters, and 15 meters", "80 meters, 20 meters, 15 meters, and 10 meters"],
    correctIndex: 2,
    reference: "2023–2027 General pool · [97.301(d)]",
  },
  {
    id: "G1A02",
    pool: "general",
    section: "G1A",
    question: "On which of the following bands is phone operation prohibited?",
    answers: ["160 meters", "30 meters", "17 meters", "12 meters"],
    correctIndex: 1,
    reference: "2023–2027 General pool · [97.305]",
  },
  {
    id: "G1A05",
    pool: "general",
    section: "G1A",
    question: "On which of the following frequencies are General class licensees prohibited from operating as control operator?",
    answers: ["7.125 MHz to 7.175 MHz", "28.000 MHz to 28.025 MHz", "21.275 MHz to 21.300 MHz", "All these choices are correct"],
    correctIndex: 0,
    reference: "2023–2027 General pool · [97.301(d)]",
  },
  {
    id: "E1A01",
    pool: "extra",
    section: "E1A",
    question: "Why is it not legal to transmit a 3 kHz bandwidth USB signal with a carrier frequency of 14.348 MHz?",
    answers: ["USB is not used on 20-meter phone", "The lower 1 kHz of the signal is outside the 20-meter band", "14.348 MHz is outside the 20-meter band", "The upper 1 kHz of the signal is outside the 20-meter band"],
    correctIndex: 3,
    reference: "2024–2028 Amateur Extra pool · [97.305, 97.307(b)]",
  },
  {
    id: "E1A02",
    pool: "extra",
    section: "E1A",
    question: "When using a transceiver that displays the carrier frequency of phone signals, which displayed frequency represents the lowest frequency at which a properly adjusted LSB emission will be totally within the band?",
    answers: ["The exact lower band edge", "300 Hz above the lower band edge", "1 kHz above the lower band edge", "3 kHz above the lower band edge"],
    correctIndex: 3,
    reference: "2024–2028 Amateur Extra pool · [97.301, 97.305]",
  },
  {
    id: "E1A05",
    pool: "extra",
    section: "E1A",
    question: "Who must be in physical control of the station apparatus of an amateur station aboard any vessel or craft that is documented or registered in the United States?",
    answers: ["Only a person with an FCC Marine Radio license grant", "Only a person named in an amateur station license grant", "Any person holding an FCC issued amateur license or who is authorized for alien reciprocal operation", "Any person named in an amateur station license grant or a person holding an unrestricted Radiotelephone Operator Permit"],
    correctIndex: 2,
    reference: "2024–2028 Amateur Extra pool · [97.5]",
  },
];

const xpForNextLevel = (level: number) => 1000 + (level - 1) * 250;

async function getPlayer(): Promise<HamquestPlayer> {
  const [existing] = await db
    .select()
    .from(hamquestPlayersTable)
    .where(eq(hamquestPlayersTable.id, 1))
    .limit(1);

  if (existing) return existing;

  const [created] = await db
    .insert(hamquestPlayersTable)
    .values({
      id: 1,
      username: "SignalSeeker",
      callsign: "KN6EON",
      level: 4,
      xp: 2460,
      streak: 4,
      contacts: 12,
      regions: 3,
    })
    .returning();

  return created;
}

function toPlayer(player: HamquestPlayer) {
  return {
    username: player.username,
    callsign: player.callsign,
    level: player.level,
    xp: player.xp,
    xpToNext: xpForNextLevel(player.level),
    rank: player.level >= 5 ? "General" : "Technician",
    streak: player.streak,
  };
}

router.get("/hamquest/dashboard", async (_req, res) => {
  const player = await getPlayer();
  res.json({
    player: toPlayer(player),
    missions: getMissionsForLevel(player.level),
    activity,
    contacts: player.contacts,
    regions: player.regions,
  });
});

router.get("/hamquest/missions", async (req, res) => {
  const player = await getPlayer();
  res.json(getMissionsForLevel(player.level));
});

router.post("/hamquest/missions/:missionId/complete", async (req, res) => {
  const params = CompleteHamquestMissionParams.parse(req.params);
  const mission = missionCatalog.find((item) => item.id === params.missionId);

  if (!mission) {
    res.status(404).json({ error: "Mission not found" });
    return;
  }

  const player = await getPlayer();
  if (player.level < mission.requiredLevel) {
    res.status(403).json({ error: `Reach level ${mission.requiredLevel} to unlock this mission.` });
    return;
  }
  if (completedMissionIds.has(mission.id)) {
    res.status(409).json({ error: "Mission already complete" });
    return;
  }
  const nextXp = player.xp + mission.reward;
  const nextLevel = nextXp >= xpForNextLevel(player.level) ? player.level + 1 : player.level;
  const levelUp = nextLevel > player.level;

  await db
    .update(hamquestPlayersTable)
    .set({
      xp: nextXp,
      level: nextLevel,
      contacts: player.contacts + (mission.id === "first-contact" ? 1 : 0),
      updatedAt: new Date(),
    })
    .where(eq(hamquestPlayersTable.id, player.id));

  completedMissionIds.add(mission.id);

  res.json({
    xpEarned: mission.reward,
    totalXp: nextXp,
    level: nextLevel,
    levelUp,
    message: levelUp ? `Level up. Welcome to level ${nextLevel}.` : `${mission.title} complete. Nice work.`,
  });
});

router.get("/hamquest/signals", (_req, res) => {
  res.json(signalChallenge);
});

router.post("/hamquest/signals/answer", async (req, res) => {
  const body = AnswerHamquestSignalBody.parse(req.body);
  const correct = body.challengeId === signalChallenge.id && body.answer === "FT8 / digital";
  const player = await getPlayer();

  if (correct) {
    await db
      .update(hamquestPlayersTable)
      .set({ xp: player.xp + 40, streak: player.streak + 1, updatedAt: new Date() })
      .where(eq(hamquestPlayersTable.id, player.id));
  }

  res.json({
    correct,
    explanation: correct
      ? "FT8 uses tightly timed digital tones designed to pull weak signals from the noise."
      : "Listen for the repeating, computer-timed tones. That cadence is the clue for FT8.",
    xpEarned: correct ? 40 : 0,
    nextStreak: correct ? player.streak + 1 : 0,
  });
});

router.get("/hamquest/qso", (_req, res) => {
  res.json(qsoScenario);
});

router.post("/hamquest/qso/respond", async (req, res) => {
  const body = RespondHamquestQsoBody.parse(req.body);
  const correct =
    body.scenarioId === qsoScenario.id &&
    body.option === qsoScenario.options[0];
  const player = await getPlayer();

  if (correct) {
    await db
      .update(hamquestPlayersTable)
      .set({
        xp: player.xp + 90,
        contacts: player.contacts + 1,
        updatedAt: new Date(),
      })
      .where(eq(hamquestPlayersTable.id, player.id));
  }

  res.json({
    correct,
    feedback: correct
      ? "Excellent protocol. You acknowledged the operator, exchanged reports, and handed the contact back cleanly."
      : "Try acknowledging the callsign, returning the signal report, and ending with 'over'.",
    score: correct ? 100 : 35,
    xpEarned: correct ? 90 : 10,
  });
});

router.get("/hamquest/leaderboard", (_req, res) => {
  res.json(leaderboard);
});

router.get("/hamquest/propagation", async (_req, res) => {
  res.json(await getPropagationSnapshot());
});

router.get("/hamquest/questions", (req, res) => {
  const { pool = "all" } = ListHamquestQuestionsQueryParams.parse(req.query);
  res.json(pool === "all" ? practiceQuestions : practiceQuestions.filter((question) => question.pool === pool));
});

router.get("/hamquest/callsigns/:callsign", async (req, res) => {
  const callsign = req.params.callsign.trim().toUpperCase();
  if (!/^[A-Z0-9/]{3,12}$/.test(callsign)) {
    res.status(400).json({ error: "Enter a valid callsign." });
    return;
  }

  try {
    const response = await fetch(`https://api.hamdb.org/v1/${encodeURIComponent(callsign)}/json/hamquest`, {
      headers: { accept: "application/json" },
      signal: AbortSignal.timeout(5000),
    });
    if (!response.ok) {
      res.status(404).json({ error: "Callsign not found in HamDB." });
      return;
    }

    const payload = (await response.json()) as {
      hamdb?: {
        callsign?: Record<string, unknown>;
        messages?: { status?: string };
      };
    };
    const result = payload.hamdb?.callsign ?? {};
    if (payload.hamdb?.messages?.status && payload.hamdb.messages.status !== "OK") {
      res.status(404).json({ error: "Callsign not found in HamDB." });
      return;
    }

    res.json({
      callsign: String(result.callsign ?? callsign),
      status: String(result.status === "A" ? "Active" : result.status ?? "Unknown"),
      name: String(result.fname ?? result.name ?? "Name unavailable"),
      city: String(result.addr2 ?? result.city ?? "Location unavailable"),
      state: String(result.state ?? ""),
      country: String(result.country ?? "United States"),
      grid: String(result.grid ?? result.grid_square ?? "Not published"),
      licenseClass: result.class ? String(result.class) : null,
      expires: result.expdate ? String(result.expdate) : null,
      source: "HamDB",
    });
  } catch {
    res.status(502).json({ error: "Callsign service is temporarily unavailable." });
  }
});

export default router;