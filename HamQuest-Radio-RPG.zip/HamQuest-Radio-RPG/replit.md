# HamQuest: The Ham Radio RPG

HamQuest turns amateur radio practice into an RPG-style learning journey with missions, signal training, simulated QSOs, exploration, and player progression.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/hamquest/src/App.tsx` — player dashboard, missions, signal lab, QSO, exploration, and leaderboard routes
- `artifacts/hamquest/src/index.css` — HamQuest command-deck theme and responsive styling
- `artifacts/api-server/src/routes/hamquest.ts` — HamQuest API handlers and seeded game content
- `lib/api-spec/openapi.yaml` — source of truth for generated HamQuest API hooks and schemas
- `lib/db/src/schema/hamquest.ts` — persisted player progression schema

## Architecture decisions

- The initial player is a seeded development profile so the first visit has meaningful progression data instead of an empty state.
- HamQuest gameplay actions use the shared API server and generated hooks; mutations invalidate the relevant dashboard and challenge queries.
- The frontend uses a dark orbital command-deck visual language with responsive navigation that collapses into a mobile bottom bar.

## Product

- Player dashboard with level, XP, streak, contacts, regions, daily activity, and mission queue
- 123 mission expeditions with level-gated unlocks and XP rewards
- HF propagation map with band conditions, path watch, and solar telemetry
- Current Technician, General, and Amateur Extra practice-pool review
- Simulated QSO conversation with etiquette scoring and XP rewards
- HamDB callsign intelligence lookup inside Live QSO
- Exploration map view and weekly leaderboard

## User preferences

- The user asked for a dark, futuristic radio and space exploration theme with neon green, blue, and amber accents.

## Gotchas

- API changes require `pnpm --filter @workspace/api-spec run codegen` before frontend hooks or server schemas are used.
- App and API services are managed by the artifact workflows; use their existing workflow names when restarting them.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
